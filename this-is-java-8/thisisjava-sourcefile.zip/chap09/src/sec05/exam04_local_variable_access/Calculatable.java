package sec05.exam04_local_variable_access;

public interface Calculatable {
	public int sum();
}
