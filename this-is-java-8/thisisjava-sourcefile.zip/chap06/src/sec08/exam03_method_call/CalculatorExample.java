package sec08.exam03_method_call;

public class CalculatorExample {
	public static void main(String[] args) {
		Calculator myCalc = new Calculator();
		myCalc.execute();
	}
}

