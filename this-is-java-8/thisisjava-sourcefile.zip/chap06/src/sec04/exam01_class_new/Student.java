package sec04.exam01_class_new;

public class Student {

}
