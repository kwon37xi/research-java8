package sec09.exam01_instance_member;

public class CarExample {
	public static void main(String[] args) {
		Car myCar = new Car("������");
		Car yourCar = new Car("����");
		
		myCar.run();
		yourCar.run();
	}
}
