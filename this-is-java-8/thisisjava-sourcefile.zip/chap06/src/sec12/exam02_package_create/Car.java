package sec12.exam02_package_create;

public class Car {

}
