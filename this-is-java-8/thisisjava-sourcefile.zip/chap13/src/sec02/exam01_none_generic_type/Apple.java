package sec02.exam01_none_generic_type;

public class Apple {

}
