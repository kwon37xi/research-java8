package verify.exam04;

public class ChildPair<K, V> extends Pair<K,V> {
	public ChildPair(K k, V v) {
		super(k, v);
	}
}
