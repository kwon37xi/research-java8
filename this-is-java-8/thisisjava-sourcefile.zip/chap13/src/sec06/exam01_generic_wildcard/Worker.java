package sec06.exam01_generic_wildcard;

public class Worker extends Person {
	public Worker(String name) {
		super(name);
	}
}
