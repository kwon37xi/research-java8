package sec06.exam01_generic_wildcard;

public class Student extends Person {
	public Student(String name) {
		super(name);
	}
}
