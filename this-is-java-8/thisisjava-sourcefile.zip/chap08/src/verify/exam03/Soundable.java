package verify.exam03;

public interface Soundable {
	String sound();
}
