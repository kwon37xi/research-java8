package sec05.exam03_method_polymorphism;

public interface Vehicle {
	public void run();
}
