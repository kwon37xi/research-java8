package sec02.exam01_interface_declaration;

public interface RemoteControl {
}
