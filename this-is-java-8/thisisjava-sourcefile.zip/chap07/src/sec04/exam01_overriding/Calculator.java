package sec04.exam01_overriding;

public class Calculator {	
	double areaCircle(double r) { 
		System.out.println("Calculator ��ü�� areaCircle() ����");
		return 3.14159 * r * r; 
	}
}

