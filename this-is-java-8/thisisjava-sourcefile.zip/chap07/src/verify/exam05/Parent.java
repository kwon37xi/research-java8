package verify.exam05;

public class Parent {
	public String name;
	
	public Parent(String name) {
		this.name = name;
	}
}
