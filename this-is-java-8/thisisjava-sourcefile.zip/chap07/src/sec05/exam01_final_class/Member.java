package sec05.exam01_final_class;

public final class Member {
}
