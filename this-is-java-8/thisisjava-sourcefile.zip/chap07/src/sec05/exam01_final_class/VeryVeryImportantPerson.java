package sec05.exam01_final_class;

//public class VeryVeryImportantPerson extends Member {
public class VeryVeryImportantPerson {
}
