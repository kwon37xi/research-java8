package sec07.exam01_promotion;

public class D extends B {

}
