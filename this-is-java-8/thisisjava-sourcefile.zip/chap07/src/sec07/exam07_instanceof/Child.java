package sec07.exam07_instanceof;

public class Child extends Parent {
}
