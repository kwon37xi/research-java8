package verify;
public class Exercise06 {
	public static void main(String[] args) {
		int lengthTop = 5;
		int lengthBottom = 10;
		int height = 7;
		double area = (   (10+5) * 7 / 2.0    );
		System.out.println(area);
	}
}




