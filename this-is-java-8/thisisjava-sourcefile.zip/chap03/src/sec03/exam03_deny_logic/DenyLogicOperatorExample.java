package sec03.exam03_deny_logic;

public class DenyLogicOperatorExample {
	public static void main(String[] args) {
		boolean play = true;
    System.out.println(play);

    play = !play;
    System.out.println(play);

    play = !play;
    System.out.println(play);
	}
}
