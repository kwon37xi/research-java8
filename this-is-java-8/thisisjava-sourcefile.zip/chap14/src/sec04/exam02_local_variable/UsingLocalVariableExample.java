package sec04.exam02_local_variable;

public class UsingLocalVariableExample {
	public static void main(String... args) {
		UsingLocalVariable ulv = new UsingLocalVariable();
		ulv.method(20);
	}
}

