package sec04.exam02_local_variable;

public interface MyFunctionalInterface {
    public void method();
}

