package sec03.exam05_deep_clone;

public class Car {
	public String model;
	
	public Car(String model) {
		this.model = model;
	}
}
