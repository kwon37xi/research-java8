package sec06.exam03_newinstance;

public interface Action {
	public void execute();
}
